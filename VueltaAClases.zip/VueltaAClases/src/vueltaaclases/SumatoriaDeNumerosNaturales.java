/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vueltaaclases;
import java.util.Scanner;

/**
 *
 * @author Lucas Agustín Morales Romero
 */
public class SumatoriaDeNumerosNaturales {
    //public static void main (String[] args){
    int desicion;
    int alcance;
    int sumatoria = 0;
    int i;
    int k;
    Scanner scanner = new Scanner(System.in);
    System.out.println("Sumatoria de N numeros naturales");
    System.err.println("Ingrese la cantidad de numeros naturales a contar");
    alcance = scanner.nextInt();
    System.out.println("¿Se debe contar al cero como inicio de la lista? (1 = si 0 = no)");
    desicion = scanner.nextInt();
    if (desicion == 1){
        for (i = 0; i < alcance; i++){
            sumatoria = sumatoria + i;
        }
    System.out.println("La sumatoria de los numeros naturales contando el cero hasta el numero " + alcance + ", da como resultado: " + sumatoria);
    sumatoria = 0;
    }
    else{
        for (k = 1; k <= alcance; k++){
            sumatoria = sumatoria + k;
        }
    System.out.println("La sumatoria de los numeros naturales sin contar el cero hasta el numero " + alcance + ", da como resultado: " + sumatoria);
    sumatoria = 0;
    }
    
    
    }
}
