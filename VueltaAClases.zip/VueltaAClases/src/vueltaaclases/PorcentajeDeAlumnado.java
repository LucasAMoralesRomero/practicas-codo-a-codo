/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vueltaaclases;

/**
 *
 * @author Lucas Agustín Morales Romero
 */
public class PorcentajeDeAlumnado {
//public static void main (String[] args){
int niños = 27;
int niñas = 54;
System.out.println("Cantidad de niños: " + niños + ", representa el " + ( niños * 100 / ( niños + niñas ) ) +"%");
System.out.println("Cantidad de niñas:" + niñas + ", representa el " + (niñas * 100 / (niños + niñas ) ) +"%");
}
}
