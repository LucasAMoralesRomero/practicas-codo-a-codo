/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vueltaaclases;
import java.util.Scanner;
/**
 *
 * @author Lucas Agustín Morales Romero
 */
public class SumatoriaDeNumerosConArrayDeNNumeros {
public static void main (String[] args){
int ValorDeSuma = 0;
int CantidadDeNumeros = 0;
int Promedio = 0;
int i;
int k;
int lectura;
Scanner scanner = new Scanner(System.in);
System.out.println("Sumatoria de numeros N con un array de N numeros");
System.out.println("Ingrese la cantidad de numeros a sumar");
CantidadDeNumeros = scanner.nextInt();
int array[];
array  = new int[CantidadDeNumeros];
for (k = 0; k < CantidadDeNumeros; k++){
    System.out.println("Ingrese el valor para la posicion " + k +" del array" );
    lectura = scanner.nextInt();
    array[k] = lectura;
}
for (i = 0; i < CantidadDeNumeros; i++){
    ValorDeSuma = ValorDeSuma + array[i];
}
Promedio = ValorDeSuma / CantidadDeNumeros;
System.out.println("La Sumatoria de los numeros desde el cero hasta " + CantidadDeNumeros + ", da como resultado: " + ValorDeSuma);
System.out.println("El promedio de la sumatoria de: " + Promedio);
}
    
}
