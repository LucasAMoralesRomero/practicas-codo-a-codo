/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vueltaaclases;
import java.util.Scanner;

/**
 *
 * @author Lucas Agustín Morales Romero
 */
public class IntercambioDeValores {
//public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);

int Valor1 = 0;
int Valor2 = 0;
int Valor3 = 0;
int Swap = 0;
System.out.println("Ingrese el primer valor");
Valor1 = scanner.nextInt();
System.out.println("Ingrese el segundo valor");
Valor2 = scanner.nextInt();
System.out.println("Ingrese el tercer valor");
Valor3 = scanner.nextInt();
System.out.println("Valor1: " + Valor1 + " /Valor2: " + Valor2 + " /Valor3: " + Valor3 + " /Swap: " + Swap);
Swap = Valor1;
Valor1 = Valor3;
Valor3 = Swap;
System.out.println("-------------------------------------------------------------------------------------");
System.out.println("Valor1: " + Valor1 + " /Valor2: " + Valor2 + " /Valor3: " + Valor3 + " /Swap: " + Swap);





        
}
}