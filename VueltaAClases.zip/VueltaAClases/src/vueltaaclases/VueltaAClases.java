/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vueltaaclases;
import java.util.Scanner;


/**
 *
 * @author Lucas Agustín Morales Romero
 */
public class VueltaAClases {

    /**
     * @param args the command line arguments
     */
//public static void main(String[] args) {
float Numero1 = 0;
float Numero2 = 0;
float Operacion = 0;
Scanner scanner = new Scanner(System.in);
System.out.println ("Ingrese el primer numero");
Numero1 = scanner.nextFloat();
System.out.println("Ingrese el segundo numero");
Numero2 = scanner.nextFloat();
Operacion = Numero1+Numero2;
System.out.println("La suma de " + Numero1 + " y " + Numero2 + " es igual a: " + Operacion);
Operacion = 0;
Operacion = Numero1-Numero2;
System.out.println("La resta de " + Numero1 + " y " + Numero2 + " es igual a: "+ Operacion);
Operacion = 0;
Operacion = (Numero1/Numero2);
System.out.println("El resultado de la division de " + Numero1 + " y " + Numero2 + " es igual a: "+ Operacion);
Operacion = 0;
Operacion = Numero1*Numero2;
System.out.println("El resultado de la multiplocacion de " + Numero1 + " y " + Numero2 + " es igual a: " + Operacion);

   } 
}